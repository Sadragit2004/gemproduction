// let btn = document.getElementById('secrit');

// btn.addEventListener('click', function(event) {
//     let access = event.isTrusted;

//     if (!access) {
//         alert("دسترسی غیرمجاز! شما به صفحه دیگری هدایت خواهید شد.");
//         window.location.href = "https://www.google.com";
//     }
    
// });




